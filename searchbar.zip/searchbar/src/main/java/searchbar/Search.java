package searchbar;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class Search {
	
	
	
	// in the 404 error we check for the project name error then like searchbar the it maps to /searchbar so we need to redirect the to the page that we need
	// otherwies just simple / like the below code 
	
	@RequestMapping("/")
	public String searchpage() {
		System.out.println("ur at the home page enter the url");
		return "index";
	}
	
	
	@RequestMapping("/search")
	public RedirectView search(@RequestParam("query") String query , Model model) {		
		String url = "https://www.google.com/search?q="+query;
		
		RedirectView redirectView = new RedirectView();
		
		redirectView.setUrl(url);

		return redirectView;
	}
}
